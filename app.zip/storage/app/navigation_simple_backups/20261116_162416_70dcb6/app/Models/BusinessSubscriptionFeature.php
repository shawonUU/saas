<?php

namespace App\Models;

use App\Models\Concerns\ErpCrud;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BusinessSubscriptionFeature extends Model
{
    use ErpCrud, SoftDeletes;

    protected $guarded = [];
    protected function casts(): array
    {
        return ['is_enabled' => 'boolean', 'starts_at' => 'datetime', 'ends_at' => 'datetime'];
    }
    public function subscription() { return $this->belongsTo(BusinessSubscription::class, 'business_subscription_id'); }
    public function category() { return $this->belongsTo(BusinessCategory::class, 'business_category_id'); }
}
