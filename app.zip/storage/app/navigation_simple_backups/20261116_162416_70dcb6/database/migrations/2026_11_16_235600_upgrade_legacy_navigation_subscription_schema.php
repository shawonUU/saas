<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Existing installations may already have run the old migrations, which had
 * business_id required in plan pivots and business_subscription_id required in
 * overrides. Fresh installs get the corrected definitions in the old migration
 * files; this migration is an additive upgrade path for databases already run.
 * Keep data; do NOT drop or truncate existing subscriptions or user access.
 */
return new class extends Migration
{
    public function up(): void
    {
        foreach (['subscription_plan_modules', 'subscription_plan_menus', 'subscription_plan_child_menus'] as $table) {
            if (!Schema::hasTable($table)) {
                $column = [
                    'subscription_plan_modules' => 'module_id',
                    'subscription_plan_menus' => 'menu_id',
                    'subscription_plan_child_menus' => 'child_menu_id',
                ][$table];
                $target = [
                    'module_id' => 'modules', 'menu_id' => 'menus',
                    'child_menu_id' => 'child_menus',
                ][$column];
                Schema::create($table, function (Blueprint $blueprint) use ($column, $target) {
                    $blueprint->id();
                    $blueprint->foreignId('subscription_plan_id')->constrained('subscription_plans')->cascadeOnDelete();
                    $blueprint->foreignId('business_category_id')->constrained('business_categories')->cascadeOnDelete();
                    $blueprint->foreignId($column)->constrained($target)->cascadeOnDelete();
                    $blueprint->boolean('is_enabled')->default(true);
                    $blueprint->unique(['subscription_plan_id', 'business_category_id', $column], 'sp_upgrade_' . $column);
                    $blueprint->erpCommonColumns();
                });
                continue;
            }
            if (!Schema::hasColumn($table, 'business_category_id')) {
                Schema::table($table, function (Blueprint $blueprint) {
                    $blueprint->unsignedBigInteger('business_category_id')->nullable()->index();
                });
            }
            if (Schema::hasColumn($table, 'business_id')) {
                Schema::table($table, function (Blueprint $blueprint) {
                    // Old plan pivot stored individual business_id as NOT NULL.
                    // Category-wide Basic plan rows must be allowed to leave it NULL.
                    $blueprint->unsignedBigInteger('business_id')->nullable()->change();
                });
            }
        }

        if (Schema::hasTable('subscription_plan_modules') && Schema::hasColumn('subscription_plan_modules', 'feature_key')) {
            Schema::table('subscription_plan_modules', function (Blueprint $table) {
                $table->string('feature_key')->nullable()->change();
            });
        }

        foreach (['business_modules', 'business_menus', 'business_child_menus'] as $table) {
            if (!Schema::hasTable($table)) continue;
            if (Schema::hasColumn($table, 'business_subscription_id')) {
                Schema::table($table, function (Blueprint $blueprint) {
                    $blueprint->unsignedBigInteger('business_subscription_id')->nullable()->change();
                });
            }
        }
        if (Schema::hasTable('business_modules') && Schema::hasColumn('business_modules', 'feature_key')) {
            Schema::table('business_modules', function (Blueprint $table) {
                $table->string('feature_key')->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        // Intentionally no destructive rollback of existing data/constraints.
    }
};
