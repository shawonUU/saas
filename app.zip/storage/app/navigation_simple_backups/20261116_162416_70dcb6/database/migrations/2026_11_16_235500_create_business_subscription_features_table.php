<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('business_subscription_features')) return;

        Schema::create('business_subscription_features', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_subscription_id')->constrained('business_subscriptions')->cascadeOnDelete();
            $table->foreignId('business_category_id')->constrained('business_categories')->cascadeOnDelete();
            $table->foreignId('module_id')->nullable()->constrained('modules')->cascadeOnDelete();
            $table->foreignId('menu_id')->nullable()->constrained('menus')->cascadeOnDelete();
            $table->foreignId('child_menu_id')->nullable()->constrained('child_menus')->cascadeOnDelete();
            $table->string('feature_key');
            $table->enum('source', ['Plan', 'Override'])->default('Plan');
            $table->boolean('is_enabled')->default(true);
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->text('notes')->nullable();
            $table->unique(['business_subscription_id', 'feature_key'], 'bs_feature_unique');
            $table->index(['business_subscription_id', 'business_category_id'], 'bs_category_index');
            $table->erpCommonColumns();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('business_subscription_features');
    }
};
