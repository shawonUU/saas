<style>
/* Solid, high-contrast configuration UI; modal intentionally above sticky header/sidebar. */
.cfg-page .workspace-content{max-width:1700px}
.cfg-heading{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:22px}
.cfg-heading h1{font:800 25px Manrope,sans-serif;color:var(--ws-text);letter-spacing:-.5px}
.cfg-heading p{margin-top:7px;color:var(--ws-muted);font-size:13px}
.cfg-eyebrow{font-size:12px;color:var(--ws-muted);font-weight:700;margin-bottom:5px}
.cfg-panel{background:var(--ws-panel);border:1px solid var(--ws-line);border-radius:16px;overflow:hidden;color:var(--ws-text);box-shadow:0 9px 28px rgba(24,32,54,.06)}
.cfg-toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:17px;border-bottom:1px solid var(--ws-line)}
.cfg-input{height:39px;width:100%;padding:0 11px;border:1px solid #cfd7e5;border-radius:9px;color:#18263c!important;background:#fff!important;font:500 13px 'DM Sans',sans-serif;outline:0}
.cfg-input::placeholder{color:#8996ab}.cfg-input:focus{border-color:#6659dc;box-shadow:0 0 0 3px rgba(99,91,223,.14)}
.cfg-search{flex:1;min-width:210px}.cfg-small{width:auto;min-width:110px}
.cfg-btn{height:38px;padding:0 14px;display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid #cfd7e5;background:#fff;color:#273550;border-radius:9px;font-size:12px;font-weight:800;cursor:pointer;text-decoration:none;white-space:nowrap}
.cfg-btn:hover{border-color:#6254db;color:#5147ca}.cfg-primary{background:#5547d9;border-color:#5547d9;color:#fff}.cfg-primary:hover{background:#4537c0;color:#fff}
.cfg-danger{border-color:#f1d2d5;color:#ac3341}.cfg-danger:hover{border-color:#dd9ba2;color:#a12636}
.cfg-btn:focus-visible,.cfg-dialog button:focus-visible{outline:3px solid #ab9fff;outline-offset:2px}
.cfg-btn:disabled{opacity:.5;cursor:not-allowed}.cfg-code{font:650 11px ui-monospace,monospace;color:var(--ws-muted)}
.cfg-table-scroll{width:100%;overflow:auto;max-height:72vh}.cfg-table{width:100%;border-collapse:separate;border-spacing:0;text-align:left;white-space:nowrap;font-size:12px}
.cfg-table th{position:sticky;top:0;z-index:2;background:#f0f3f8;color:#43516a;padding:12px 13px;border-bottom:1px solid #dfe4ed;font-size:12px}
.cfg-table th a{color:inherit;text-decoration:none}.cfg-table th a:hover{color:#4c40c3}
.cfg-table td{padding:13px;border-bottom:1px solid var(--ws-line);color:var(--ws-text);max-width:260px;text-overflow:ellipsis;overflow:hidden}
.cfg-table tbody tr:hover td{background:rgba(86,73,218,.05)}
.cfg-table .cfg-filter-row th{position:sticky;top:41px;z-index:2;padding:7px;background:#f8faff;border-bottom:2px solid #dbe2ec}
.cfg-filter-row[hidden]{display:none}.cfg-filter-row .cfg-input{min-width:105px;height:33px;font-size:11px}
.cfg-status{display:inline-flex;border-radius:50px;padding:5px 9px;background:#dff7e7;color:#17633e;font-weight:800;font-size:11px}
.cfg-status.off{background:#ffeaea;color:#a33440}.cfg-swatches{display:inline-block;width:15px;height:15px;border-radius:50%;border:1px solid #c6cbdb;vertical-align:middle;margin-right:6px}
.cfg-actions{display:flex;align-items:center;gap:6px}.cfg-actions .cfg-btn{height:31px;padding:0 10px}
.cfg-bottom{padding:16px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;color:var(--ws-muted);font-size:12px}
.cfg-pagination{display:flex;gap:7px;align-items:center}.cfg-pagination a,.cfg-pagination span{border:1px solid var(--ws-line);border-radius:8px;padding:8px 11px;color:var(--ws-text);text-decoration:none}.cfg-pagination span{opacity:.65}
.cfg-empty{padding:46px 15px!important;text-align:center;color:var(--ws-muted)!important}.cfg-count{font-size:12px;color:var(--ws-muted)}
/* Modal is moved to body before opening, escaping sidebar and header stacking contexts. */
.cfg-modal{position:fixed!important;inset:0!important;z-index:2147483000!important;background:rgba(7,14,30,.78)!important;backdrop-filter:blur(5px);-webkit-backdrop-filter:blur(5px);display:flex;justify-content:center;align-items:center;padding:22px 14px;overflow-y:auto}
.cfg-modal[hidden]{display:none!important}.cfg-dialog{width:min(720px,100%);max-height:min(90dvh,850px);display:flex;flex-direction:column;background:#fff!important;color:#17243c!important;border:1px solid #d8e0ec!important;border-radius:17px;overflow:hidden;box-shadow:0 30px 110px rgba(0,0,0,.65)!important}
.cfg-dialog-header{padding:21px 24px;display:flex;justify-content:space-between;align-items:center;gap:18px;background:#f3f6ff!important;color:#17243c;border-bottom:1px solid #d9dff0}
.cfg-dialog-header h2{font:800 20px Manrope,sans-serif;color:#17243c!important}.cfg-dialog-header p{font-size:12px;color:#54627b!important;margin-top:6px}
.cfg-dialog-close{font-size:20px;width:36px;padding:0;flex-shrink:0}
.cfg-form{display:flex;flex-direction:column;min-height:0;overflow:auto}.cfg-fields{padding:22px 24px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:17px;background:#fff!important}
.cfg-field{min-width:0}.cfg-field.wide{grid-column:1/-1}.cfg-field label{display:block;color:#253653!important;font-size:13px;font-weight:750;margin-bottom:8px}
.cfg-field .cfg-input{background:#fff!important;color:#16243a!important;border:1px solid #bac6d8!important;height:43px;font-size:13px}
.cfg-field .cfg-input:focus{border-color:#5145cf!important;box-shadow:0 0 0 3px rgba(81,69,207,.14)}
.cfg-field textarea.cfg-input{min-height:78px;padding:12px;resize:vertical;height:auto}.cfg-field select.cfg-input{cursor:pointer}
.cfg-required{color:#ce3b4c}.cfg-actions-footer{position:sticky;bottom:0;display:flex;justify-content:flex-end;gap:10px;padding:17px 24px;border-top:1px solid #d9e0ee;background:#f8faff!important}
.cfg-notice{margin:15px 24px 0;padding:12px 14px;background:#fff0f1;color:#962b36;border:1px solid #efbac0;border-radius:9px;font-size:12px;line-height:1.6}
html[data-theme="dark"] .cfg-page .cfg-panel{background:#1d283d}html[data-theme="dark"] .cfg-table th{background:#2a354a;color:#e1e8f5}
html[data-theme="dark"] .cfg-table .cfg-filter-row th{background:#223048}
html[data-theme="dark"] .cfg-page .cfg-input{background:#fff!important;color:#18263c!important}
@media(max-width:720px){.cfg-fields{grid-template-columns:1fr;padding:17px}.cfg-field.wide{grid-column:auto}.cfg-dialog-header{padding:17px}.cfg-actions-footer{padding:13px 17px}.cfg-toolbar{padding:12px}.cfg-table-scroll{max-height:65vh}.cfg-heading h1{font-size:22px}}
</style>
