<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Independent ERP masters. Existing business_customers (customer login) is untouched. */
    public function up(): void
    {
        $builders = [
            'config_customers' => function (Blueprint $t) {
                $t->string('phone')->nullable(); $t->string('email')->nullable();
                $t->text('address')->nullable(); $t->text('notes')->nullable();
            },
            'config_suppliers' => function (Blueprint $t) {
                $t->string('contact_person')->nullable(); $t->string('phone')->nullable(); $t->string('email')->nullable();
                $t->text('address')->nullable(); $t->text('notes')->nullable();
            },
            'config_units' => function (Blueprint $t) { $t->string('symbol'); $t->text('description')->nullable(); },
            'config_sizes' => function (Blueprint $t) { $t->text('description')->nullable(); },
            'config_colors' => function (Blueprint $t) { $t->string('hex_code', 7)->nullable(); $t->text('description')->nullable(); },
            'config_brands' => function (Blueprint $t) { $t->text('description')->nullable(); },
            'config_categories' => function (Blueprint $t) { $t->text('description')->nullable(); },
            'config_sub_categories' => function (Blueprint $t) {
                $t->foreignId('category_id')->constrained('config_categories')->restrictOnDelete();
                $t->text('description')->nullable();
                $t->index(['business_id', 'category_id']);
            },
            'config_taxes' => function (Blueprint $t) {
                $t->decimal('rate', 8, 3); $t->string('calculation_type', 20);
                $t->text('description')->nullable();
            },
            'config_currencies' => function (Blueprint $t) {
                $t->string('currency_code', 3); $t->string('symbol', 20);
                $t->decimal('exchange_rate', 16, 6)->default(1);
                $t->boolean('is_default')->default(false);
                $t->index(['business_id', 'currency_code']);
            },
            'config_payment_methods' => function (Blueprint $t) {
                $t->string('method_type', 20); $t->text('details')->nullable();
            },
            'config_shipping_methods' => function (Blueprint $t) {
                $t->decimal('charge', 14, 2)->default(0);
                $t->unsignedInteger('estimated_days')->nullable(); $t->text('description')->nullable();
            },
        ];

        foreach ($builders as $table => $fields) {
            Schema::create($table, function (Blueprint $t) use ($fields) {
                $t->id();
                $t->foreignId('business_id')->constrained('businesses')->cascadeOnDelete();
                $t->string('name');
                $fields($t);
                $t->erpCommonColumns();
                $t->index(['business_id', 'name']);
                $t->index(['business_id', 'is_active']);
            });
        }
    }

    public function down(): void
    {
        foreach ([
            'config_shipping_methods', 'config_payment_methods', 'config_currencies', 'config_taxes',
            'config_sub_categories', 'config_categories', 'config_brands', 'config_colors',
            'config_sizes', 'config_units', 'config_suppliers', 'config_customers',
        ] as $table) {
            Schema::dropIfExists($table);
        }
    }
};
