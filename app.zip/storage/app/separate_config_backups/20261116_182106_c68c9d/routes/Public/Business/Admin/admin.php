<?php

use App\Http\Controllers\Public\Business\Admin\AuthorizationController;
use App\Http\Controllers\Public\Business\Admin\BusinessUserController;
use App\Http\Controllers\Public\Business\Admin\UserController;
use App\Http\Controllers\Public\Business\Admin\WorkspaceController;
use App\Http\Controllers\Public\Business\Admin\Configurations\ConfigurationCrudController;
use Illuminate\Support\Facades\Route;


$domain=config('saas.domain');

Route::domain('admin.{business}.'.$domain)->middleware('business.resolve')->group(function(){
    Route::middleware(['portal.auth:business_admin', 'auth.session'])->group(function(){
        Route::get('/dashboard',[WorkspaceController::class,'dashboard'])->name('store.admin.dashboard');
    });
});

Route::domain('admin.{business}.'.$domain)->middleware('business.resolve')->group(function(){
    Route::middleware(['portal.auth:business_admin', 'auth.session'])->group(function(){
        Route::prefix('authorization')->name('authorization.')->group(function(){
            Route::get('/access-control',[AuthorizationController::class,'index'])->name('access-control');
            Route::get('/access-control/{memberId}',[AuthorizationController::class,'show'])->name('access-control.show');
            Route::post('/access-control/store',[AuthorizationController::class,'store'])->name('access-control.store');
            Route::get('/users',[BusinessUserController::class,'index'])->name('users.index');
            Route::post('/users',[BusinessUserController::class,'store'])->name('users.store');
            Route::put('/users/{memberId}',[BusinessUserController::class,'update'])->name('users.update');
            Route::delete('/users/{memberId}',[BusinessUserController::class,'destroy'])->name('users.destroy');
        });

        // Configuration masters have dedicated CRUD controllers; register BEFORE the generic feature route.
        Route::prefix('configurations')->name('store.admin.configurations.')->group(function () {
            Route::get('/{resource}', [ConfigurationCrudController::class, 'index'])->name('index');
            Route::post('/{resource}', [ConfigurationCrudController::class, 'store'])->name('store');
            Route::put('/{resource}/{record}', [ConfigurationCrudController::class, 'update'])->whereNumber('record')->name('update');
            Route::delete('/{resource}/{record}', [ConfigurationCrudController::class, 'destroy'])->whereNumber('record')->name('destroy');
        });

        Route::get('/{module}/{menu}/{child?}',[WorkspaceController::class,'feature'])->name('store.admin.feature');   

    });
});
