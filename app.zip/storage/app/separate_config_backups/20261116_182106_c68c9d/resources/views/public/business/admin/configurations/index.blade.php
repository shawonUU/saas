@extends('public.business.admin.layout')

@push('styles')
<style>


.workspace-layout{--ws-panel:#fff;--ws-bg:#f6f8fc;--ws-text:#172138;--ws-muted:#7d879b;--ws-line:#e9edf5;--ws-accent:#635bdf;display:grid;grid-template-columns:276px minmax(0,1fr);min-height:calc(100vh - 76px);background:var(--ws-bg);color:var(--ws-text)}

.workspace-layout *{box-sizing:border-box}.workspace-layout a{text-decoration:none}.ws-svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex-shrink:0}.workspace-content{min-width:0;padding:32px clamp(20px,3.2vw,54px) 60px;max-width:1800px;width:100%;margin:auto}.ws-toolbar,.ws-header-actions,.ws-heading-row,.ws-section-head,.ws-side-brand,.ws-side-user,.ws-section-title,.ws-link,.ws-quick-link,.ws-module-name{display:flex;align-items:center}.ws-toolbar{justify-content:space-between;gap:16px;margin-bottom:28px}.ws-breadcrumb{display:flex;align-items:center;gap:9px;font-size:12px;color:var(--ws-muted);font-weight:700}.ws-breadcrumb strong{color:var(--ws-text)}.ws-breadcrumb .ws-svg{width:15px;height:15px}.ws-header-actions{gap:10px}.ws-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:0 15px;border:1px solid var(--ws-line);border-radius:11px;background:var(--ws-panel);color:var(--ws-text);font-size:12px;font-weight:800;cursor:pointer;transition:.2s}.ws-button:hover{border-color:#bfc3ed;color:var(--ws-accent)}.ws-button .ws-svg{width:16px;height:16px}.ws-button-primary{background:#645ce2;color:#fff;border-color:#645ce2}.ws-button-primary:hover{background:#5149cb;color:#fff}.ws-mobile-menu{display:none}.ws-hero{position:relative;display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:25px;align-items:center;overflow:hidden;padding:37px 42px;min-height:244px;border-radius:22px;background:linear-gradient(113deg,#171f3e 0%,#252751 64%,#363477 100%);color:#fff;box-shadow:0 16px 35px rgba(31,39,76,.08)}.ws-hero:after{content:"";position:absolute;width:370px;height:370px;right:-110px;top:-180px;border:1px solid rgba(255,255,255,.12);border-radius:50%;pointer-events:none}.ws-hero-copy{position:relative;z-index:2}.ws-eyebrow{display:inline-flex;align-items:center;gap:8px;color:#c7cafa;font-size:11px;letter-spacing:1.5px;font-weight:800;text-transform:uppercase}.ws-eyebrow:before{content:"";width:7px;height:7px;border-radius:50%;background:#9ee5cb;box-shadow:0 0 0 4px rgba(158,229,203,.13)}.ws-hero h1{font-size:clamp(26px,3vw,38px);line-height:1.18;letter-spacing:-1.5px;margin:15px 0 12px;font-family:Manrope,'DM Sans',sans-serif;font-weight:800}.ws-hero p{color:#c6cbe5;font-size:13px;line-height:1.85;max-width:560px}.ws-hero-meta{display:flex;flex-wrap:wrap;gap:9px;margin-top:22px}.ws-hero-chip{display:inline-flex;gap:7px;align-items:center;padding:8px 11px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.07);border-radius:9px;color:#e8eafd;font-size:11px;font-weight:700}.ws-hero-chip .ws-svg{width:14px;height:14px}.ws-hero-art{position:relative;height:160px;display:flex;align-items:center;justify-content:center}.ws-art-circle{position:relative;width:156px;height:156px;border-radius:36px;display:grid;place-items:center;background:linear-gradient(140deg,rgba(255,255,255,.2),rgba(255,255,255,.05));border:1px solid rgba(255,255,255,.22);box-shadow:0 17px 50px rgba(0,0,0,.13);transform:rotate(-10deg)}.ws-art-circle .ws-svg{width:72px;height:72px;color:#dce1ff;stroke-width:1.2;transform:rotate(10deg)}.ws-art-float{position:absolute;background:#fff;color:#252a57;display:flex;align-items:center;justify-content:center;width:57px;height:57px;box-shadow:0 10px 34px rgba(11,16,48,.18);border-radius:18px}.ws-art-float .ws-svg{width:26px;height:26px}.ws-art-float.one{top:0;right:2px;transform:rotate(12deg);color:#655ce1}.ws-art-float.two{bottom:0;left:0;transform:rotate(-12deg);color:#17a985}.ws-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin:22px 0 32px}.ws-stat{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;background:var(--ws-panel);border:1px solid var(--ws-line);border-radius:17px;padding:23px 23px 20px;min-height:145px;box-shadow:0 5px 18px rgba(29,40,75,.025)}.ws-stat small{color:var(--ws-muted);font-weight:700;font-size:12px}.ws-stat strong{display:block;font-family:Manrope,'DM Sans',sans-serif;font-size:32px;line-height:1.2;letter-spacing:-1.2px;margin:12px 0 7px;font-weight:800}.ws-stat p{color:var(--ws-muted);font-size:11px;line-height:1.5}.ws-stat-icon{width:45px;height:45px;border-radius:13px;display:grid;place-items:center;flex-shrink:0}.ws-stat-icon.violet{background:#efedff;color:#6057d9}.ws-stat-icon.teal{background:#e3f7f3;color:#159981}.ws-stat-icon.orange{background:#fff2e6;color:#e39542}.ws-lower-grid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(290px,.85fr);gap:20px;align-items:start}.ws-panel{background:var(--ws-panel);border:1px solid var(--ws-line);border-radius:18px;padding:25px;min-width:0}.ws-panel + .ws-panel{margin-top:0}.ws-section-head{justify-content:space-between;gap:16px;margin-bottom:20px}.ws-section-title{gap:10px}.ws-title-icon{width:34px;height:34px;display:grid;place-items:center;border-radius:10px;background:#f0efff;color:#6157d8}.ws-title-icon .ws-svg{width:17px;height:17px}.ws-section-head h2{font-family:Manrope,'DM Sans',sans-serif;font-size:16px;letter-spacing:-.4px}.ws-section-head p{font-size:11px;color:var(--ws-muted);margin-top:5px;line-height:1.5}.ws-mini-count{background:#f5f6fc;border:1px solid var(--ws-line);border-radius:9px;padding:7px 10px;font-size:11px;color:var(--ws-muted);font-weight:800;white-space:nowrap}.ws-quick-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.ws-quick-link{gap:12px;min-width:0;border:1px solid var(--ws-line);background:var(--ws-panel);padding:14px 12px;border-radius:12px;transition:.2s}.ws-quick-link:hover{border-color:#bbb5f5;background:rgba(99,91,223,.035);transform:translateY(-2px)}.ws-quick-symbol{width:38px;height:38px;display:grid;place-items:center;border-radius:11px;background:#f0efff;color:#635bdf;flex-shrink:0}.ws-quick-symbol .ws-svg{width:18px;height:18px}.ws-quick-info{min-width:0;flex:1}.ws-quick-info strong{display:block;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-size:12px;color:var(--ws-text)}.ws-quick-info small{display:block;margin-top:5px;color:var(--ws-muted);font-size:10px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.ws-quick-link>.ws-svg{width:14px;height:14px;color:#a9b0c0}.ws-module-list{display:flex;flex-direction:column;gap:10px}.ws-module-card{display:flex;align-items:center;gap:12px;border:1px solid var(--ws-line);border-radius:13px;padding:13px 12px;min-width:0;transition:.2s}.ws-module-card:hover{border-color:#c7c4ec}.ws-module-avatar{display:grid;place-items:center;width:42px;height:42px;flex-shrink:0;border-radius:12px;background:#eae9ff;color:#6259d7;font-size:16px;font-weight:800}.ws-module-card:nth-child(3n+2) .ws-module-avatar{background:#e3f8f3;color:#16987f}.ws-module-card:nth-child(3n+3) .ws-module-avatar{background:#fff0e5;color:#d68a3b}.ws-module-info{flex:1;min-width:0}.ws-module-info strong{display:block;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ws-module-info span{display:block;font-size:11px;color:var(--ws-muted);margin-top:6px}.ws-module-arrow{display:grid;place-items:center;width:28px;height:28px;border:1px solid var(--ws-line);border-radius:8px;color:#8d95a7;flex-shrink:0}.ws-module-arrow .ws-svg{width:15px;height:15px}.ws-module-arrow.disabled{opacity:.45}.ws-note{display:flex;gap:11px;align-items:flex-start;margin-top:17px;background:#f7f8ff;border-radius:12px;padding:14px;color:#70798f;font-size:11px;line-height:1.7}.ws-note .ws-svg{width:17px;height:17px;color:#635bdf;margin-top:1px}.ws-empty-state{text-align:center;border:1px dashed var(--ws-line);border-radius:13px;padding:34px 20px;color:var(--ws-muted);font-size:12px;line-height:1.8}.ws-empty-state .ws-svg{width:30px;height:30px;margin-bottom:10px;color:#a6a9c1}.ws-empty-state strong{display:block;color:var(--ws-text);font-size:13px;margin-bottom:3px}.ws-footer-note{display:flex;justify-content:space-between;gap:15px;margin-top:24px;color:var(--ws-muted);font-size:11px}.ws-footer-note strong{color:var(--ws-text)}

/* Sidebar */

.workspace-sidebar{position:sticky;top:76px;height:calc(100vh - 76px);background:var(--ws-panel);border-right:1px solid var(--ws-line);display:flex;flex-direction:column;min-width:0;z-index:30}.ws-side-top{padding:25px 18px 17px;border-bottom:1px solid var(--ws-line)}.ws-side-brand{gap:11px;min-width:0}.ws-side-logo{display:grid;place-items:center;width:43px;height:43px;border-radius:13px;background:#eeeaff;color:#655bdd;font-size:20px;font-weight:800;flex-shrink:0;object-fit:contain}.ws-side-brand-text{min-width:0;flex:1}.ws-side-brand-text strong{display:block;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ws-side-brand-text small{display:block;font-size:10px;margin-top:5px;color:var(--ws-muted);font-weight:700}.ws-close-sidebar{display:none;border:0;background:transparent;color:var(--ws-muted);padding:5px;cursor:pointer}.ws-side-search{position:relative;margin-top:24px}.ws-side-search .ws-svg{position:absolute;top:12px;left:13px;width:17px;height:17px;color:#98a0b0}.ws-side-search input{width:100%;height:41px;border:1px solid var(--ws-line);outline:0;background:var(--ws-bg);color:var(--ws-text);border-radius:11px;padding:0 12px 0 40px;font-family:inherit;font-size:12px}.ws-side-search input:focus{border-color:#a49efa;box-shadow:0 0 0 3px rgba(99,91,223,.09)}.ws-side-scroll{flex:1;overflow:auto;scrollbar-width:thin;padding:18px 12px 14px}.ws-nav-label{padding:0 11px;margin:2px 0 9px;color:#a0a7b8;font-weight:800;font-size:10px;letter-spacing:1.2px;text-transform:uppercase}.ws-nav-dashboard{display:flex;gap:12px;align-items:center;padding:12px 13px;border-radius:11px;font-size:12px;font-weight:800;color:#596276;transition:.2s}.ws-nav-dashboard .ws-svg{width:18px;height:18px}.ws-nav-dashboard:hover,.ws-nav-dashboard.active{background:#eeeefe;color:#5b53d8}.ws-nav-separator{height:1px;background:var(--ws-line);margin:16px 10px}.ws-nav-group{margin:0 0 11px}.ws-module-label{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:11px 12px 8px;font-size:10px;color:#a0a7b8;letter-spacing:.8px;text-transform:uppercase;font-weight:800}.ws-module-label span:first-child{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ws-module-label em{font-style:normal;font-size:10px;color:#a4a9b8}.ws-menu{margin:2px 0}.ws-menu summary{list-style:none;display:flex;gap:10px;align-items:center;cursor:pointer;padding:11px 13px;color:#596276;font-size:12px;font-weight:700;border-radius:10px;transition:.2s}.ws-menu summary::-webkit-details-marker{display:none}.ws-menu summary:hover{background:var(--ws-bg);color:var(--ws-accent)}.ws-menu summary>.ws-svg:first-child{width:16px;height:16px;color:#929bb0}.ws-menu summary .ws-menu-text{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ws-menu summary .ws-chevron{width:14px;height:14px;color:#a1a8b6;transition:transform .2s}.ws-menu[open] summary .ws-chevron{transform:rotate(180deg)}.ws-children{display:flex;flex-direction:column;gap:2px;padding:3px 0 5px 30px}.ws-children a{display:flex;align-items:center;gap:9px;border-radius:9px;padding:9px 10px;font-size:11px;color:#7c859a;min-width:0;transition:.2s}.ws-children a:before{content:"";width:5px;height:5px;background:#cad0de;border-radius:50%;flex-shrink:0}.ws-children a span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ws-children a:hover,.ws-children a.active{color:#5b54d6;background:#f0efff;font-weight:800}.ws-children a.active:before{background:#665de2}.ws-menu[hidden],.ws-nav-group[hidden],.ws-children a[hidden]{display:none!important}.ws-search-empty{font-size:11px;color:var(--ws-muted);padding:15px;text-align:center}.ws-side-bottom{border-top:1px solid var(--ws-line);padding:15px 17px 18px}.ws-side-user{gap:10px;min-width:0}.ws-user-avatar{display:grid;place-items:center;width:38px;height:38px;border-radius:11px;background:#ebeafd;color:#6259d7;font-size:15px;font-weight:800;flex-shrink:0}.ws-user-text{flex:1;min-width:0}.ws-user-text strong{display:block;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ws-user-text small{display:block;font-size:10px;color:var(--ws-muted);margin-top:5px}.ws-signout{width:31px;height:31px;display:grid;place-items:center;border:1px solid var(--ws-line);border-radius:9px;background:var(--ws-panel);color:var(--ws-muted);cursor:pointer}.ws-signout:hover{color:#d45a69;border-color:#f3cbd0}.ws-signout .ws-svg{width:16px;height:16px}.ws-sidebar-overlay{display:none}

html[data-theme="dark"] .workspace-layout{--ws-panel:#1c2435;--ws-bg:#111827;--ws-text:#eef1fb;--ws-muted:#a0aec0;--ws-line:#344055;--ws-accent:#aca7ff}html[data-theme="dark"] .ws-nav-dashboard.active,html[data-theme="dark"] .ws-nav-dashboard:hover,html[data-theme="dark"] .ws-children a.active,html[data-theme="dark"] .ws-children a:hover{background:#34305e;color:#dedaff}html[data-theme="dark"] .ws-title-icon,html[data-theme="dark"] .ws-quick-symbol,html[data-theme="dark"] .ws-side-logo,html[data-theme="dark"] .ws-user-avatar{background:#34305e;color:#d8d5ff}html[data-theme="dark"] .ws-mini-count,html[data-theme="dark"] .ws-note{background:#222b40}html[data-theme="dark"] .ws-stat-icon.violet{background:#37305b}html[data-theme="dark"] .ws-stat-icon.teal{background:#163f3c}html[data-theme="dark"] .ws-stat-icon.orange{background:#4c3526}html[data-theme="dark"] .ws-module-avatar{background:#34305e}html[data-theme="dark"] .ws-menu summary:hover{background:#252f43}

@media(max-width:1200px){.ws-lower-grid{grid-template-columns:1fr}.ws-quick-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}

@media(max-width:1050px){.workspace-layout{display:block}.workspace-sidebar{position:fixed;top:0;left:0;width:min(310px,86vw);height:100dvh;z-index:220;transform:translateX(-105%);transition:transform .25s}.ws-sidebar-open .workspace-sidebar{transform:translateX(0)}.ws-sidebar-open{overflow:hidden}.ws-sidebar-open .ws-sidebar-overlay{display:block;position:fixed;inset:0;background:rgba(12,18,37,.57);z-index:210}.ws-close-sidebar,.ws-mobile-menu{display:inline-flex}.workspace-content{padding:26px 23px 45px}}

@media(max-width:680px){.workspace-content{padding:18px 14px 36px}.ws-toolbar{margin-bottom:17px}.ws-header-actions{gap:7px}.ws-header-actions .ws-store-label{display:none}.ws-header-actions .ws-button{padding:0 11px;min-height:38px}.ws-breadcrumb{font-size:11px}.ws-hero{grid-template-columns:1fr;padding:27px 25px;min-height:0;border-radius:17px}.ws-hero h1{font-size:27px}.ws-hero-art{display:none}.ws-stats{gap:10px;margin:14px 0 19px;grid-template-columns:repeat(2,minmax(0,1fr))}.ws-stat{padding:16px;min-height:129px}.ws-stat:nth-child(3){grid-column:1 / -1}.ws-stat strong{font-size:26px}.ws-stat-icon{width:37px;height:37px}.ws-stat-icon .ws-svg{width:17px;height:17px}.ws-panel{padding:17px;border-radius:15px}.ws-lower-grid{gap:15px}.ws-quick-grid{grid-template-columns:1fr}.ws-footer-note{flex-direction:column;gap:6px}}


</style>
<style>
.cfg-page .workspace-content{max-width:1750px}.cfg-heading{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:20px;flex-wrap:wrap}.cfg-heading h1{font:800 25px Manrope,sans-serif;color:var(--ws-text);letter-spacing:-.6px}.cfg-heading p{font-size:12px;color:var(--ws-muted);margin-top:6px}.cfg-panel{background:var(--ws-panel);color:var(--ws-text);border:1px solid var(--ws-line);border-radius:16px;overflow:hidden;box-shadow:0 5px 19px rgba(20,30,60,.025)}
.cfg-toolbar{display:flex;align-items:center;gap:9px;flex-wrap:wrap;padding:16px 18px;border-bottom:1px solid var(--ws-line)}.cfg-search{flex:1;min-width:190px}.cfg-input{height:36px;width:100%;border:1px solid var(--ws-line);border-radius:9px;background:var(--ws-panel);color:var(--ws-text);font:500 12px 'DM Sans',sans-serif;padding:0 11px;outline:0}.cfg-input:focus{border-color:#aaa1f0;box-shadow:0 0 0 3px rgba(92,83,219,.08)}.cfg-small{width:auto;min-width:88px}.cfg-btn{display:inline-flex;justify-content:center;align-items:center;gap:7px;border:1px solid var(--ws-line);background:var(--ws-panel);color:var(--ws-text);height:36px;padding:0 13px;border-radius:9px;cursor:pointer;font:700 12px 'DM Sans',sans-serif;white-space:nowrap}.cfg-btn:hover{border-color:#9f98f2;color:var(--ws-accent)}.cfg-primary{background:#645ce2;border-color:#645ce2;color:#fff}.cfg-primary:hover{background:#5048c5;color:#fff}.cfg-danger{color:#b93140}.cfg-btn:disabled{opacity:.45;cursor:not-allowed}.cfg-table-scroll{width:100%;overflow:auto;max-height:70vh}.cfg-table{width:100%;border-collapse:separate;border-spacing:0;font-size:12px;text-align:left;white-space:nowrap}.cfg-table th{position:sticky;top:0;background:var(--ws-bg);z-index:2;border-bottom:1px solid var(--ws-line);padding:12px 13px;color:var(--ws-muted);font-size:11px}.cfg-table th a{color:inherit;text-decoration:none}.cfg-table th a:hover{color:var(--ws-accent)}.cfg-table td{border-bottom:1px solid var(--ws-line);padding:12px 13px;color:var(--ws-text);max-width:270px;overflow:hidden;text-overflow:ellipsis}.cfg-table tr:hover td{background:rgba(99,91,223,.035)}.cfg-table .cfg-filter-row th{top:36px;padding:7px 8px;background:var(--ws-panel)}.cfg-filter-row[hidden]{display:none}.cfg-filter-row .cfg-input{height:31px;min-width:100px;font-size:11px}.cfg-status{display:inline-flex;padding:5px 9px;border-radius:20px;background:#e4f8ed;color:#138354;font-weight:800;font-size:10px}.cfg-status.off{background:#fff0f0;color:#c45457}.cfg-code{font:600 11px ui-monospace,monospace;color:var(--ws-muted)}.cfg-actions{display:flex;gap:5px}.cfg-actions .cfg-btn{height:29px;padding:0 9px}.cfg-bottom{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px;flex-wrap:wrap;color:var(--ws-muted);font-size:12px}.cfg-pagination{display:flex;gap:6px;flex-wrap:wrap}.cfg-pagination a,.cfg-pagination span{padding:7px 11px;border:1px solid var(--ws-line);border-radius:8px;color:var(--ws-text);font-weight:700}.cfg-pagination span{opacity:.5}.cfg-empty{padding:44px 10px!important;text-align:center;color:var(--ws-muted)!important}.cfg-modal{position:fixed;inset:0;z-index:550;background:rgba(12,18,37,.60);display:flex;align-items:center;justify-content:center;padding:15px}.cfg-modal[hidden]{display:none}.cfg-dialog{display:flex;flex-direction:column;width:min(680px,100%);max-height:92dvh;background:var(--ws-panel);border-radius:17px;color:var(--ws-text);box-shadow:0 20px 65px rgba(0,0,0,.25);overflow:hidden}.cfg-dialog-header{display:flex;align-items:center;justify-content:space-between;padding:20px 23px;border-bottom:1px solid var(--ws-line)}.cfg-dialog-header h2{font:800 19px Manrope,sans-serif}.cfg-dialog-header p{font-size:11px;color:var(--ws-muted);margin-top:5px}.cfg-form{display:flex;flex-direction:column;overflow:auto}.cfg-fields{padding:22px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}.cfg-field{min-width:0}.cfg-field.wide{grid-column:1/-1}.cfg-field label{display:block;margin-bottom:6px;font-weight:700;font-size:12px}.cfg-field textarea{padding:10px;resize:vertical;height:auto;min-height:65px}.cfg-required{color:#e46a72}.cfg-actions-footer{display:flex;justify-content:flex-end;gap:8px;padding:16px 22px;border-top:1px solid var(--ws-line)}.cfg-notice{padding:12px 14px;border:1px solid #f8c8cb;background:#fff3f3;color:#ad2b36;border-radius:8px;font-size:12px;margin:13px 20px 0}.cfg-count{color:var(--ws-muted);font-size:12px}.cfg-swatches{display:inline-flex;width:13px;height:13px;border-radius:50%;border:1px solid var(--ws-line);vertical-align:middle;margin-right:6px}html[data-theme="dark"] .cfg-status{background:#173e2d;color:#74e8ae}html[data-theme="dark"] .cfg-status.off{background:#492829;color:#f4a6a7}
@media(max-width:700px){.cfg-fields{grid-template-columns:1fr}.cfg-heading h1{font-size:22px}.cfg-toolbar{padding:12px}.cfg-actions-footer{padding:12px}.cfg-table-scroll{max-height:62vh}}
</style>
@endpush

@section('content')
@php
    $businessKey = request()->route('business');
    $businessKey = is_object($businessKey) ? ($businessKey->domain ?? $businessKey->slug ?? '') : $businessKey;
    $indexUrl = route('store.admin.configurations.index', ['business'=>$businessKey,'resource'=>$urlResource]);
    $storeUrl = route('store.admin.configurations.store', ['business'=>$businessKey,'resource'=>$urlResource]);
    $updateTemplate = route('store.admin.configurations.update', ['business'=>$businessKey,'resource'=>$urlResource,'record'=>'__ID__']);
    $deleteTemplate = route('store.admin.configurations.destroy', ['business'=>$businessKey,'resource'=>$urlResource,'record'=>'__ID__']);
    $recordPayload = $records->getCollection()->mapWithKeys(fn($r) => [$r->id => $r->only(array_merge(['id','is_active'],array_keys($definition['fields'])))])->all();
    $categoryNames = $categories->pluck('name', 'id');
@endphp
<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" style="position:absolute;width:0;height:0;overflow:hidden">
    <symbol id="ws-i-grid" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></symbol>
    <symbol id="ws-i-folder" viewBox="0 0 24 24"><path d="M3 6a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6Z"/></symbol>
    <symbol id="ws-i-chevron" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></symbol>
    <symbol id="ws-i-search" viewBox="0 0 24 24"><circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/></symbol>
    <symbol id="ws-i-x" viewBox="0 0 24 24"><path d="M5 5l14 14M19 5 5 19"/></symbol>
    <symbol id="ws-i-menu" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></symbol>
    <symbol id="ws-i-logout" viewBox="0 0 24 24"><path d="M9 4H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4m5-4 4-4-4-4m4 4H9"/></symbol>
    <symbol id="ws-i-home" viewBox="0 0 24 24"><path d="m3 10 9-7 9 7v10H3z"/></symbol>
    <symbol id="ws-i-store" viewBox="0 0 24 24"><path d="M3 10h18l-2-6H5l-2 6ZM5 10v11h14V10"/></symbol>
</svg>

<div class="workspace-layout cfg-page">
    @include('public.business.admin.sidebar')
    <div class="ws-sidebar-overlay" data-ws-sidebar-overlay></div>
    <div class="workspace-content">
        <div class="cfg-heading">
            <div><div class="cfg-count">{{ t('Configurations','কনফিগারেশন') }} / {{ $definition['title'] }}</div><h1>{{ session('portal_lang') === 'bn' ? $definition['title_bn'] : $definition['title'] }}</h1><p>{{ t('Manage master data for this business. All results are filtered in the database.','এই ব্যবসার মাস্টার ডেটা পরিচালনা করুন। সব ফিল্টার ডাটাবেজে প্রয়োগ হয়।') }}</p></div>
            @if($permissions['create'])<button type="button" class="cfg-btn cfg-primary" id="cfg-add">+ {{ t('Add New','নতুন যোগ করুন') }}</button>@endif
        </div>
        <section class="cfg-panel">
            <form id="cfg-filter-form" action="{{ $indexUrl }}" method="GET" class="cfg-toolbar">
                <input class="cfg-input cfg-search" name="search" value="{{ $search }}" placeholder="{{ t('Search records...','তথ্য খুঁজুন...') }}" aria-label="Search" />
                <select class="cfg-input cfg-small" name="per_page" aria-label="Rows per page">
                    @foreach([10,15,25,50,100] as $size)<option value="{{ $size }}" @selected($perPage === $size)>{{ $size }} / page</option>@endforeach
                </select>
                <button type="submit" class="cfg-btn cfg-primary">{{ t('Apply Filters','ফিল্টার দিন') }}</button>
                <button type="button" class="cfg-btn" id="cfg-toggle-filters" aria-expanded="true">{{ t('Hide Column Filters','কলাম ফিল্টার লুকান') }}</button>
                <a class="cfg-btn" href="{{ $indexUrl }}">{{ t('Reset','রিসেট') }}</a>
            </form>
            <div class="cfg-table-scroll">
                <table class="cfg-table">
                    <thead>
                    <tr>
                        @foreach($columns as $column => $meta)
                            <th scope="col"><a href="{{ request()->fullUrlWithQuery(['sort'=>$column,'dir'=>$sort===$column && $dir==='asc'?'desc':'asc','page'=>1]) }}">{{ $meta['label'] }} @if($sort === $column){{ $dir === 'asc' ? '↑':'↓' }}@endif</a></th>
                        @endforeach
                        <th>{{ t('Actions','অ্যাকশন') }}</th>
                    </tr>
                    <tr class="cfg-filter-row" id="cfg-filter-row">
                        @foreach($columns as $column => $meta)
                            <th>
                                @if(in_array($meta['type'], ['status','boolean','select','category'],true))
                                    <select name="f[{{ $column }}]" form="cfg-filter-form" class="cfg-input" aria-label="Filter {{ $meta['label'] }}">
                                        <option value="">{{ t('All','সব') }}</option>
                                        @if(in_array($meta['type'], ['status','boolean'],true))
                                            <option value="1" @selected((string)($filters[$column]??'')==='1')>{{ $meta['type']==='status'?'Active':'Yes' }}</option>
                                            <option value="0" @selected((string)($filters[$column]??'')==='0')>{{ $meta['type']==='status'?'Inactive':'No' }}</option>
                                        @elseif($meta['type'] === 'category')
                                            @foreach($categories as $category)<option value="{{ $category->id }}" @selected((string)($filters[$column]??'')===(string)$category->id)>{{ $category->name }}</option>@endforeach
                                        @else
                                            @foreach($meta['options'] as $value=>$text)<option value="{{ $value }}" @selected((string)($filters[$column]??'')===(string)$value)>{{ $text }}</option>@endforeach
                                        @endif
                                    </select>
                                @else
                                    <input form="cfg-filter-form" class="cfg-input" type="{{ $meta['type']==='date'?'date':'text' }}" name="f[{{ $column }}]" value="{{ is_scalar($filters[$column]??null)?$filters[$column]:'' }}" placeholder="{{ $meta['type']==='date'?'YYYY-MM-DD':'Filter...' }}" aria-label="Filter {{ $meta['label'] }}" />
                                @endif
                            </th>
                        @endforeach
                        <th><button form="cfg-filter-form" class="cfg-btn cfg-primary" type="submit">{{ t('Go','যান') }}</button></th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($records as $record)
                        <tr>
                            @foreach($columns as $column => $meta)
                                <td title="{{ (string) $record->getAttribute($column) }}">
                                    @if($column === 'code')<span class="cfg-code">{{ $record->code }}</span>
                                    @elseif($column === 'is_active')<span class="cfg-status {{ $record->is_active?'':'off' }}">{{ $record->is_active?'Active':'Inactive' }}</span>
                                    @elseif($meta['type']==='boolean'){{ $record->getAttribute($column)?'Yes':'No' }}
                                    @elseif($meta['type']==='date'){{ $record->getAttribute($column)?->format('d M Y, H:i') ?? '—' }}
                                    @elseif($meta['type']==='category'){{ $categoryNames[$record->getAttribute($column)] ?? '—' }}
                                    @elseif($meta['type']==='select'){{ $meta['options'][$record->getAttribute($column)] ?? $record->getAttribute($column) }}
                                    @elseif($meta['type']==='hex' && $record->getAttribute($column))<span class="cfg-swatches" style="background:{{ preg_match('/^#[0-9a-fA-F]{6}$/',(string)$record->getAttribute($column))?$record->getAttribute($column):'transparent' }}"></span>{{ $record->getAttribute($column) }}
                                    @else {{ $record->getAttribute($column) ?? '—' }}
                                    @endif
                                </td>
                            @endforeach
                            <td><div class="cfg-actions">
                                @if($permissions['update'])<button type="button" class="cfg-btn cfg-edit" data-id="{{ $record->id }}">{{ t('Edit','এডিট') }}</button>@endif
                                @if($permissions['delete'])
                                    <form method="POST" action="{{ route('store.admin.configurations.destroy',['business'=>$businessKey,'resource'=>$urlResource,'record'=>$record->id]) }}" class="cfg-delete-form">
                                        @csrf @method('DELETE')<button type="submit" class="cfg-btn cfg-danger">{{ t('Delete','ডিলিট') }}</button>
                                    </form>
                                @endif
                                @unless($permissions['update'] || $permissions['delete'])<span class="cfg-count">—</span>@endunless
                            </div></td>
                        </tr>
                    @empty
                        <tr><td colspan="{{ count($columns)+1 }}" class="cfg-empty">{{ t('No records found. Try resetting the filters.','কোনো তথ্য পাওয়া যায়নি। ফিল্টার রিসেট করুন।') }}</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            <div class="cfg-bottom">
                <span>{{ $records->firstItem()??0 }}–{{ $records->lastItem()??0 }} {{ t('of','মোট') }} {{ $records->total() }} {{ t('records','রেকর্ড') }}</span>
                <div class="cfg-pagination">
                    @if($records->previousPageUrl())<a href="{{ $records->previousPageUrl() }}">&larr; Prev</a>@else<span>Prev</span>@endif
                    <span>{{ $records->currentPage() }} / {{ max(1,$records->lastPage()) }}</span>
                    @if($records->nextPageUrl())<a href="{{ $records->nextPageUrl() }}">Next &rarr;</a>@else<span>Next</span>@endif
                </div>
            </div>
        </section>
    </div>
</div>

@if($permissions['create'] || $permissions['update'])
<div class="cfg-modal" id="cfg-modal" hidden>
    <div class="cfg-dialog" role="dialog" aria-modal="true" aria-labelledby="cfg-dialog-title">
        <div class="cfg-dialog-header"><div><h2 id="cfg-dialog-title">{{ t('Create','তৈরি') }} {{ $definition['title'] }}</h2><p>{{ t('Enter information and save.','তথ্য দিয়ে সেভ করুন।') }}</p></div><button type="button" class="cfg-btn" id="cfg-close" aria-label="Close">×</button></div>
        <form class="cfg-form" method="POST" id="cfg-form" action="{{ $storeUrl }}">
            @csrf
            <input type="hidden" name="_method" id="cfg-method" value="PUT" disabled />
            <input type="hidden" name="form_mode" id="cfg-form-mode" value="create" />
            <input type="hidden" name="edit_id" id="cfg-edit-id" value="" />
            @if($errors->any())<div class="cfg-notice">{{ $errors->first() }}</div>@endif
            <div class="cfg-fields">
                @foreach($definition['fields'] as $field => $meta)
                    <div class="cfg-field {{ in_array($meta['type'],['textarea'],true)?'wide':'' }}">
                        <label for="cfg-{{ $field }}">{{ $meta['label'] }} @if($meta['required'])<span class="cfg-required">*</span>@endif</label>
                        @if($meta['type']==='textarea')
                            <textarea class="cfg-input" id="cfg-{{ $field }}" name="{{ $field }}" maxlength="2000" @required($meta['required'])></textarea>
                        @elseif($meta['type']==='select' || $meta['type']==='category' || $meta['type']==='boolean')
                            <select class="cfg-input" id="cfg-{{ $field }}" name="{{ $field }}" @required($meta['required'])>
                                @if($meta['type']!=='boolean')<option value="">Select {{ $meta['label'] }}</option>@endif
                                @if($meta['type']==='category')
                                    @foreach($categories as $category)<option value="{{ $category->id }}">{{ $category->name }}</option>@endforeach
                                @elseif($meta['type']==='boolean')<option value="0">No</option><option value="1">Yes</option>
                                @else @foreach($meta['options'] as $value=>$text)<option value="{{ $value }}">{{ $text }}</option>@endforeach
                                @endif
                            </select>
                        @else
                            <input class="cfg-input" id="cfg-{{ $field }}" name="{{ $field }}"
                                type="{{ $meta['type']==='email'?'email':(in_array($meta['type'],['decimal','integer'],true)?'number':'text') }}"
                                @if($meta['type']==='decimal') step="0.000001" min="0" @elseif($meta['type']==='integer') step="1" min="0" @endif
                                maxlength="{{ $meta['type']==='currency'?3:($meta['type']==='hex'?7:255) }}"
                                @required($meta['required']) />
                        @endif
                    </div>
                @endforeach
                <div class="cfg-field"><label for="cfg-is-active">{{ t('Status','স্ট্যাটাস') }}</label>
                    <select class="cfg-input" id="cfg-is-active" name="is_active"><option value="1">Active</option><option value="0">Inactive</option></select>
                </div>
            </div>
            <div class="cfg-actions-footer"><button type="button" class="cfg-btn" id="cfg-cancel">{{ t('Cancel','বাতিল') }}</button><button class="cfg-btn cfg-primary" id="cfg-save" type="submit">{{ t('Save','সেভ') }}</button></div>
        </form>
    </div>
</div>
@endif
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-ws-sidebar-toggle],[data-ws-sidebar-overlay]').forEach(button => button.addEventListener('click', () => document.body.classList.toggle('ws-sidebar-open')));
    const filterRow = document.getElementById('cfg-filter-row');
    const toggle = document.getElementById('cfg-toggle-filters');
    const storageKey = 'cfg-column-filters';
    let visible = true;
    try { visible = localStorage.getItem(storageKey) !== 'hidden'; } catch (e) {}
    function refreshFilters() { filterRow.hidden = !visible; toggle.setAttribute('aria-expanded', String(visible)); toggle.textContent = visible ? 'Hide Column Filters' : 'Show Column Filters'; }
    refreshFilters();
    toggle.addEventListener('click', () => { visible = !visible; try { localStorage.setItem(storageKey, visible ? 'shown' : 'hidden'); } catch (e) {} refreshFilters(); });
    document.querySelectorAll('.cfg-delete-form').forEach(form => form.addEventListener('submit', event => { if (!confirm('Delete this record?')) event.preventDefault(); }));

    const modal = document.getElementById('cfg-modal');
    if (!modal) return;
    const form = document.getElementById('cfg-form');
    const method = document.getElementById('cfg-method');
    const mode = document.getElementById('cfg-form-mode');
    const editId = document.getElementById('cfg-edit-id');
    const title = document.getElementById('cfg-dialog-title');
    const fields = @json(array_keys($definition['fields']));
    const records = @json($recordPayload);
    const createUrl = @json($storeUrl);
    const updateTemplate = @json($updateTemplate);
    const resourceTitle = @json($definition['title']);
    let lastFocus;
    function openModal(id) {
        lastFocus = document.activeElement;
        form.reset();
        const row = id ? records[String(id)] : null;
        mode.value = row ? 'edit' : 'create';
        editId.value = row ? String(id) : '';
        form.action = row ? updateTemplate.replace('__ID__', String(id)) : createUrl;
        method.disabled = !row;
        title.textContent = (row ? 'Edit ' : 'Create ') + resourceTitle;
        if (row) {
            fields.forEach(field => { const input = form.elements.namedItem(field); if (input) input.value = row[field] === null || row[field] === undefined ? '' : String(row[field]); });
            form.elements.namedItem('is_active').value = row.is_active ? '1' : '0';
        }
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        modal.querySelector('input:not([type="hidden"]),select,textarea')?.focus();
    }
    function closeModal() { modal.hidden = true; document.body.style.overflow = ''; lastFocus?.focus(); }
    document.getElementById('cfg-add')?.addEventListener('click', () => openModal(null));
    document.querySelectorAll('.cfg-edit').forEach(button => button.addEventListener('click', () => openModal(button.dataset.id)));
    document.getElementById('cfg-close').addEventListener('click', closeModal);
    document.getElementById('cfg-cancel').addEventListener('click', closeModal);
    modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && !modal.hidden) closeModal(); });

    const errorMode = @json(old('form_mode'));
    const errorEditId = @json(old('edit_id'));
    const oldData = @json(old());
    if (Object.keys(oldData).length && @json($errors->any())) {
        openModal(errorMode === 'edit' && records[String(errorEditId)] ? errorEditId : null);
        fields.concat(['is_active']).forEach(field => { const input = form.elements.namedItem(field); if (input && Object.prototype.hasOwnProperty.call(oldData, field)) input.value = String(oldData[field]??''); });
    }
});
</script>
@endpush
