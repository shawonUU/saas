<?php

namespace App\Http\Controllers\Public\Business\Admin\Configurations;

use App\Http\Controllers\Controller;
use App\Models\Business;
use App\Models\BusinessUser;
use App\Models\ConfigurationRecord;
use App\Services\BusinessNavigation;
use App\Support\ConfigurationResources;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class ConfigurationCrudController extends Controller
{
    private function context(Request $request, string $resource): array
    {
        $slug = ConfigurationResources::canonical($resource);
        $definition = ConfigurationResources::get($slug);
        abort_unless($definition, 404);

        $business = $request->attributes->get('current_business');
        abort_unless($business instanceof Business, 404);
        $sessionUser = Auth::guard('business_admin')->user();
        abort_unless($sessionUser && (int) $sessionUser->business_id === (int) $business->id, 403);

        $user = BusinessUser::query()->with('role')
            ->where('business_id', $business->id)->findOrFail($sessionUser->id);
        $modules = app(BusinessNavigation::class)->forBusiness($business, $user);
        $module = $modules->firstWhere('slug', 'configurations');
        $menu = $module?->menus->firstWhere('slug', $slug);
        abort_unless($menu && (int) $menu->children_count === 0, 403, 'Configuration access denied.');

        $isOwner = $user->isOwnerOf($business);
        $permissions = ['create' => $isOwner, 'update' => $isOwner, 'delete' => $isOwner];
        if (!$isOwner) {
            $accesses = $user->accesses()->where('module_id', $module->id)
                ->where('menu_id', $menu->id)->whereNull('child_menu_id')
                ->where('is_active', true)->where('approval_status', 'Approved')->get();
            foreach (['create', 'update', 'delete'] as $permission) {
                $permissions[$permission] = $accesses->contains(fn($access) =>
                    (bool) $access->can_view && (bool) $access->{'can_'.$permission});
            }
        }

        return [$slug, $definition, $business, $user, $modules, $permissions];
    }

    private function model(string $table): ConfigurationRecord
    {
        return ConfigurationRecord::forTable($table);
    }

    private function scopedRecord(ConfigurationRecord $model, Business $business, int $id): ConfigurationRecord
    {
        return $model->newQuery()->where('business_id', $business->id)->findOrFail($id);
    }

    private function checkWrite(array $permissions, string $action): void
    {
        abort_unless($permissions[$action] ?? false, 403, 'You do not have permission to '.$action.'.');
    }

    public function index(Request $request, string $business, string $resource)
    {
        [$slug, $definition, $business, $user, $modules, $permissions] = $this->context($request, $resource);
        $fields = $definition['fields'];
        $table = $definition['table'];
        $query = $this->model($table)->newQuery()->where('business_id', $business->id);
        $search = mb_substr(trim((string) $request->query('search', '')), 0, 100);

        if ($search !== '') {
            $searchable = array_keys(array_filter($fields, fn($field) => in_array($field['type'], ['text', 'phone', 'email', 'textarea', 'currency', 'hex'], true)));
            $query->where(function ($q) use ($search, $searchable) {
                $q->where('code', 'like', '%'.$search.'%');
                foreach ($searchable as $column) $q->orWhere($column, 'like', '%'.$search.'%');
            });
        }

        $columns = ['id' => ['label' => 'ID', 'type' => 'integer']];
        $columns['code'] = ['label' => 'Code', 'type' => 'text'];
        foreach ($fields as $key => $field) $columns[$key] = $field;
        $columns['is_active'] = ['label' => 'Status', 'type' => 'status'];
        $columns['created_at'] = ['label' => 'Created', 'type' => 'date'];
        $columns['updated_at'] = ['label' => 'Updated', 'type' => 'date'];

        $filters = $request->query('f', []);
        if (!is_array($filters)) $filters = [];
        $filters = array_intersect_key($filters, $columns);
        foreach ($filters as $column => $input) {
            if (!is_scalar($input)) continue;
            $value = trim(mb_substr((string) $input, 0, 120));
            if ($value === '') continue;
            $type = $columns[$column]['type'];
            if (in_array($type, ['status', 'boolean'], true)) {
                if (in_array($value, ['0', '1'], true)) $query->where($column, (int) $value);
            } elseif (in_array($type, ['integer', 'category'], true)) {
                if (ctype_digit($value)) $query->where($column, (int) $value);
            } elseif ($type === 'decimal') {
                if (is_numeric($value)) $query->where($column, (float) $value);
            } elseif ($type === 'date') {
                if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) $query->whereDate($column, $value);
            } elseif ($type === 'select') {
                if (isset($columns[$column]['options'][$value])) $query->where($column, $value);
            } else {
                $query->where($column, 'like', '%'.$value.'%');
            }
        }

        $sort = (string) $request->query('sort', 'id');
        if (!array_key_exists($sort, $columns)) $sort = 'id';
        $dir = strtolower((string) $request->query('dir', 'desc')) === 'asc' ? 'asc' : 'desc';
        $perPage = (int) $request->query('per_page', 15);
        if (!in_array($perPage, [10, 15, 25, 50, 100], true)) $perPage = 15;
        $records = $query->orderBy($sort, $dir)->orderBy('id', 'desc')->paginate($perPage)->withQueryString();

        $categories = $slug === 'sub-categories'
            ? $this->model('config_categories')->newQuery()->where('business_id', $business->id)
                ->where('is_active', true)->orderBy('name')->get(['id', 'name'])
            : collect();

        return view('public.business.admin.configurations.index', [
            'business' => $business, 'user' => $user, 'modules' => $modules,
            'title' => $definition['title'], 'definition' => $definition,
            'resource' => $slug, 'urlResource' => ConfigurationResources::urlSlug($slug),
            'records' => $records, 'columns' => $columns, 'filters' => $filters,
            'search' => $search, 'sort' => $sort, 'dir' => $dir,
            'perPage' => $perPage, 'permissions' => $permissions, 'categories' => $categories,
        ]);
    }

    private function validated(Request $request, array $definition, Business $business, ?ConfigurationRecord $record): array
    {
        $rules = [];
        foreach ($definition['fields'] as $name => $field) {
            $required = $field['required'] ? 'required' : 'nullable';
            $rules[$name] = match ($field['type']) {
                'text', 'phone' => [$required, 'string', 'max:255'],
                'currency' => [$required, 'string', 'size:3', 'regex:/^[A-Z]{3}$/'],
                'email' => [$required, 'email:rfc', 'max:255'],
                'textarea' => [$required, 'string', 'max:2000'],
                'hex' => [$required, 'regex:/^#[0-9a-fA-F]{6}$/'],
                'select' => [$required, Rule::in(array_keys($field['options']))],
                'category' => [$required, 'integer', Rule::exists('config_categories', 'id')
                    ->where('business_id', $business->id)->whereNull('deleted_at')->where('is_active', true)],
                'decimal' => [$required, 'numeric', 'min:0', 'max:'.($name === 'rate' ? '100' : '999999999')],
                'integer' => [$required, 'integer', 'min:0', 'max:1000000'],
                'boolean' => ['required', 'boolean'],
                default => throw new \LogicException('Invalid field type.'),
            };
        }
        $rules['is_active'] = ['required', 'boolean'];
        if (isset($rules['currency_code'])) {
            $rules['currency_code'][] = Rule::unique($definition['table'], 'currency_code')
                ->where('business_id', $business->id)->whereNull('deleted_at')
                ->ignore($record?->id);
        }
        $data = $request->validate($rules);
        $data['is_active'] = (bool) $data['is_active'];
        if (isset($data['currency_code'])) $data['currency_code'] = strtoupper($data['currency_code']);
        if (array_key_exists('is_default', $data)) $data['is_default'] = (bool) $data['is_default'];
        return $data;
    }

    public function store(Request $request, string $business, string $resource)
    {
        [$slug, $definition, $business, , , $permissions] = $this->context($request, $resource);
        $this->checkWrite($permissions, 'create');
        if ($slug === 'currencies') $request->merge(['currency_code' => strtoupper(trim((string)$request->input('currency_code')))]);
        $data = $this->validated($request, $definition, $business, null);

        DB::transaction(function () use ($slug, $definition, $business, $data) {
            $model = $this->model($definition['table']);
            if ($slug === 'currencies' && ($data['is_default'] ?? false)) {
                $model->newQuery()->where('business_id', $business->id)->update(['is_default' => false]);
            }
            $model->newQuery()->create(array_merge($data, [
                'business_id' => $business->id,
                'approval_status' => 'Approved', 'approved_at' => now(),
            ]));
        });
        return redirect()->route('store.admin.configurations.index', [
            'business' => $request->route('business'), 'resource' => ConfigurationResources::urlSlug($slug),
        ])->with('success', 'Created successfully.');
    }

    public function update(Request $request, string $business, string $resource, int $record)
    {
        [$slug, $definition, $business, , , $permissions] = $this->context($request, $resource);
        $this->checkWrite($permissions, 'update');
        $row = $this->scopedRecord($this->model($definition['table']), $business, $record);
        if ($slug === 'currencies') $request->merge(['currency_code' => strtoupper(trim((string)$request->input('currency_code')))]);
        $data = $this->validated($request, $definition, $business, $row);

        DB::transaction(function () use ($slug, $definition, $business, $row, $data) {
            if ($slug === 'currencies' && ($data['is_default'] ?? false)) {
                $this->model($definition['table'])->newQuery()->where('business_id', $business->id)
                    ->where('id', '!=', $row->id)->update(['is_default' => false]);
            }
            $row->update($data);
        });
        return back()->with('success', 'Updated successfully.');
    }

    public function destroy(Request $request, string $business, string $resource, int $record)
    {
        [$slug, $definition, $business, , , $permissions] = $this->context($request, $resource);
        $this->checkWrite($permissions, 'delete');
        $row = $this->scopedRecord($this->model($definition['table']), $business, $record);
        if ($slug === 'categories') {
            $inUse = $this->model('config_sub_categories')->newQuery()
                ->where('business_id', $business->id)->where('category_id', $row->id)->exists();
            if ($inUse) throw ValidationException::withMessages(['category' => 'This category has sub-categories. Delete them first.']);
        }
        $row->delete();
        return back()->with('success', 'Deleted successfully.');
    }
}
