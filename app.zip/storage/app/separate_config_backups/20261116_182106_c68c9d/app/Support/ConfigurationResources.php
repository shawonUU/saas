<?php

namespace App\Support;

/** Single whitelist for configuration master CRUD; never accepts a table name from the URL. */
final class ConfigurationResources
{
    public static function aliases(): array
    {
        return ['supplier' => 'suppliers', 'color' => 'colors'];
    }

    public static function canonical(string $slug): string
    {
        return self::aliases()[$slug] ?? $slug;
    }

    public static function urlSlug(string $canonical): string
    {
        return ['suppliers' => 'supplier', 'colors' => 'color'][$canonical] ?? $canonical;
    }

    private static function field(string $label, string $type = 'text', bool $required = false, array $options = []): array
    {
        return compact('label', 'type', 'required', 'options');
    }

    public static function all(): array
    {
        $f = self::field(...);
        return [
            'customers' => [
                'title' => 'Customers', 'title_bn' => 'কাস্টমার', 'table' => 'config_customers',
                'fields' => [
                    'name' => $f('Customer Name', 'text', true),
                    'phone' => $f('Phone', 'phone'), 'email' => $f('Email', 'email'),
                    'address' => $f('Address', 'textarea'), 'notes' => $f('Notes', 'textarea'),
                ],
            ],
            'suppliers' => [
                'title' => 'Suppliers', 'title_bn' => 'সরবরাহকারী', 'table' => 'config_suppliers',
                'fields' => [
                    'name' => $f('Supplier Name', 'text', true), 'contact_person' => $f('Contact Person'),
                    'phone' => $f('Phone', 'phone'), 'email' => $f('Email', 'email'),
                    'address' => $f('Address', 'textarea'), 'notes' => $f('Notes', 'textarea'),
                ],
            ],
            'units' => [
                'title' => 'Units', 'title_bn' => 'ইউনিট', 'table' => 'config_units',
                'fields' => ['name' => $f('Unit Name', 'text', true), 'symbol' => $f('Symbol', 'text', true), 'description' => $f('Description', 'textarea')],
            ],
            'sizes' => [
                'title' => 'Sizes', 'title_bn' => 'সাইজ', 'table' => 'config_sizes',
                'fields' => ['name' => $f('Size Name', 'text', true), 'description' => $f('Description', 'textarea')],
            ],
            'colors' => [
                'title' => 'Colors', 'title_bn' => 'রঙ', 'table' => 'config_colors',
                'fields' => ['name' => $f('Color Name', 'text', true), 'hex_code' => $f('Hex Code', 'hex'), 'description' => $f('Description', 'textarea')],
            ],
            'brands' => [
                'title' => 'Brands', 'title_bn' => 'ব্র্যান্ড', 'table' => 'config_brands',
                'fields' => ['name' => $f('Brand Name', 'text', true), 'description' => $f('Description', 'textarea')],
            ],
            'categories' => [
                'title' => 'Categories', 'title_bn' => 'ক্যাটাগরি', 'table' => 'config_categories',
                'fields' => ['name' => $f('Category Name', 'text', true), 'description' => $f('Description', 'textarea')],
            ],
            'sub-categories' => [
                'title' => 'Sub-Categories', 'title_bn' => 'সাব-ক্যাটাগরি', 'table' => 'config_sub_categories',
                'fields' => ['name' => $f('Sub-Category Name', 'text', true), 'category_id' => $f('Parent Category', 'category', true), 'description' => $f('Description', 'textarea')],
            ],
            'taxes' => [
                'title' => 'Taxes', 'title_bn' => 'ট্যাক্স', 'table' => 'config_taxes',
                'fields' => ['name' => $f('Tax Name', 'text', true), 'rate' => $f('Rate (%)', 'decimal', true), 'calculation_type' => $f('Calculation', 'select', true, ['exclusive'=>'Exclusive','inclusive'=>'Inclusive']), 'description' => $f('Description', 'textarea')],
            ],
            'currencies' => [
                'title' => 'Currencies', 'title_bn' => 'মুদ্রা', 'table' => 'config_currencies',
                'fields' => ['name' => $f('Currency Name', 'text', true), 'currency_code' => $f('ISO Code (e.g. BDT)', 'currency', true), 'symbol' => $f('Symbol', 'text', true), 'exchange_rate' => $f('Exchange Rate', 'decimal', true), 'is_default' => $f('Default', 'boolean')],
            ],
            'payment-methods' => [
                'title' => 'Payment Methods', 'title_bn' => 'পেমেন্ট পদ্ধতি', 'table' => 'config_payment_methods',
                'fields' => ['name' => $f('Method Name', 'text', true), 'method_type' => $f('Method Type', 'select', true, ['cash'=>'Cash','card'=>'Card','bank'=>'Bank','mobile'=>'Mobile Banking','other'=>'Other']), 'details' => $f('Details', 'textarea')],
            ],
            'shipping-methods' => [
                'title' => 'Shipping Methods', 'title_bn' => 'শিপিং পদ্ধতি', 'table' => 'config_shipping_methods',
                'fields' => ['name' => $f('Method Name', 'text', true), 'charge' => $f('Base Charge', 'decimal', true), 'estimated_days' => $f('Estimated Days', 'integer'), 'description' => $f('Description', 'textarea')],
            ],
        ];
    }

    public static function get(string $resource): ?array
    {
        return self::all()[self::canonical($resource)] ?? null;
    }
}
