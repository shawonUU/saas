<?php

namespace App\Models;

use App\Models\Concerns\ErpCrud;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/** Tenant configuration masters: runtime table is ALWAYS chosen from the internal whitelist. */
class ConfigurationRecord extends Model
{
    use ErpCrud, SoftDeletes;

    protected $guarded = [];
    protected $attributes = ['is_active' => 1, 'approval_status' => 'Approved'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'is_default' => 'boolean'];
    }

    public static function forTable(string $table): self
    {
        $allowed = array_column(\App\Support\ConfigurationResources::all(), 'table');
        if (!in_array($table, $allowed, true)) {
            throw new \InvalidArgumentException('Unknown configuration table.');
        }
        $model = new self();
        $model->setTable($table);
        return $model;
    }
}
