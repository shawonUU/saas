<?php

namespace Tests\Feature;

use App\Models\{Business, BusinessCategory, BusinessCategoryMenu, BusinessCategoryModule, BusinessRole, BusinessUser, BusinessUserAccess, ConfigurationRecord, Menu, Module, User};
use App\Services\BusinessSubscriptionService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ConfigurationMastersTest extends TestCase
{
    use RefreshDatabase;

    private function tenant(string $domain, bool $owner = true): array
    {
        $global = User::create(['name' => 'Test', 'email' => $domain.'@test.local', 'is_active' => true, 'approval_status' => 'Approved']);
        $category = BusinessCategory::firstOrCreate(['slug' => 'test-category'], ['name' => 'Test Category', 'is_active' => true, 'approval_status' => 'Approved']);
        $business = Business::create(['name' => $domain, 'domain' => $domain, 'owner_id' => $global->id, 'category_id' => $category->id, 'is_active' => true, 'approval_status' => 'Approved']);
        $role = BusinessRole::create(['business_id' => $business->id, 'name' => $owner ? 'Owner' : 'Staff', 'is_owner' => $owner, 'is_active' => true, 'approval_status' => 'Approved']);
        $user = BusinessUser::create(['user_id' => $global->id, 'business_id' => $business->id, 'role_id' => $role->id, 'name' => $domain, 'email' => $domain.'@test.local', 'password' => '123456789', 'is_active' => true, 'approval_status' => 'Approved']);
        $module = Module::firstOrCreate(['slug'=>'configurations'], ['name'=>'Configurations','is_active'=>true,'approval_status'=>'Approved']);
        $menu = Menu::firstOrCreate(['module_id' => $module->id,'slug' => 'suppliers'], ['name' => 'Suppliers','is_active'=>true,'approval_status'=>'Approved']);
        BusinessCategoryModule::firstOrCreate(['business_category_id'=>$category->id,'module_id'=>$module->id], ['approval_status'=>'Approved']);
        BusinessCategoryMenu::firstOrCreate(['business_category_id'=>$category->id,'menu_id'=>$menu->id], ['approval_status'=>'Approved']);
        app(BusinessSubscriptionService::class)->syncBasicPlan($category);
        app(BusinessSubscriptionService::class)->activateBasic($business);
        return compact('business', 'user', 'module', 'menu');
    }

    public function test_owner_can_manage_suppliers_with_database_filters_and_server_pagination(): void
    {
        ['business' => $business, 'user' => $user] = $this->tenant('shopone');
        $this->actingAs($user, 'business_admin');
        $url = 'http://admin.shopone.saas.test/configurations/supplier';

        $this->post($url, ['name'=>'Alpha Supplies', 'phone'=>'01711000000', 'is_active'=>'1'])->assertRedirect();
        $this->post($url, ['name'=>'Beta Supplies', 'phone'=>'01999000000', 'is_active'=>'0'])->assertRedirect();
        $this->assertDatabaseCount('config_suppliers', 2);
        $this->get($url.'?f[name]=Alpha&per_page=10')->assertOk()->assertSee('Alpha Supplies')->assertDontSee('Beta Supplies');
        $this->get($url.'?f[is_active]=0')->assertOk()->assertSee('Beta Supplies')->assertDontSee('Alpha Supplies');

        $row = ConfigurationRecord::forTable('config_suppliers')->newQuery()->where('business_id', $business->id)->where('name', 'Alpha Supplies')->firstOrFail();
        $this->put($url.'/'.$row->id, ['name'=>'Alpha Updated', 'is_active'=>'1'])->assertRedirect();
        $this->assertDatabaseHas('config_suppliers', ['id'=>$row->id, 'name'=>'Alpha Updated']);
        $this->delete($url.'/'.$row->id)->assertRedirect();
        $this->assertSoftDeleted('config_suppliers', ['id'=>$row->id]);
    }

    public function test_tenant_cannot_modify_another_tenants_configuration(): void
    {
        ['user'=>$userA] = $this->tenant('shopa');
        ['business'=>$businessB] = $this->tenant('shopb');
        $row = ConfigurationRecord::forTable('config_suppliers')->newQuery()->create([
            'business_id' => $businessB->id,'name'=>'B only','is_active'=>true,'approval_status'=>'Approved',
        ]);
        $this->actingAs($userA, 'business_admin')
            ->put('http://admin.shopa.saas.test/configurations/supplier/'.$row->id, [
                'name'=>'Changed','is_active'=>'1',
            ])->assertNotFound();
        $this->assertDatabaseHas('config_suppliers', ['id'=>$row->id,'name'=>'B only']);
    }

    public function test_staff_needs_granular_write_permission(): void
    {
        ['business'=>$business,'user'=>$staff,'module'=>$module,'menu'=>$menu] = $this->tenant('staffstore', false);
        $this->actingAs($staff, 'business_admin');
        $url='http://admin.staffstore.saas.test/configurations/supplier';
        $this->post($url, ['name'=>'Blocked','is_active'=>1])->assertForbidden();

        BusinessUserAccess::create([
            'business_user_id'=>$staff->id,'module_id'=>$module->id,'menu_id'=>$menu->id,
            'can_view'=>true,'can_create'=>true,'is_active'=>true,'approval_status'=>'Approved',
        ]);
        $this->post($url, ['name'=>'Allowed','is_active'=>1])->assertRedirect();
        $this->assertDatabaseHas('config_suppliers', ['business_id'=>$business->id, 'name'=>'Allowed']);
    }
}
