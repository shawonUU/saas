<?php
namespace App\Http\Controllers\Public\Business\Admin\Retail;
use App\Http\Controllers\Controller;
use App\Models\Retail\Quotation;
use App\Models\Retail\QuotationItem;
use App\Models\Configurations\Variant;
use App\Services\Access;
use App\Services\Lists;
use App\Services\Sales;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use Illuminate\Validation\ValidationException;
class QuotationController extends Controller {
 public function index(Request $r,Access $a){$v=$a->check($r,'sales','quotations','quotation-list');$v['records']=Lists::page(Quotation::where('business_id',$v['business']->id),$r,['id'=>'number','quote_no'=>'text','customer_name'=>'text','total'=>'number','status'=>'text','valid_until'=>'date']);return view('public.business.admin.retail.quotations.index',$v);}
 public function create(Request $r,Access $a){$v=$a->check($r,'sales','quotations','new-quotation');$v['variants']=Variant::with('product')->where('business_id',$v['business']->id)->where('is_active',true)->get();return view('public.business.admin.retail.quotations.form',$v);}
 public function store(Request $r,Access $a){$v=$a->check($r,'sales','quotations','new-quotation','create');$b=$v['business'];$d=$r->validate(['customer_name'=>'required|string|max:255','customer_phone'=>'nullable|string|max:40','valid_until'=>'nullable|date|after_or_equal:today','items'=>'required|array|min:1|max:100','items.*.variant_id'=>'required|integer','items.*.quantity'=>'required|numeric|gt:0|max:999999']);DB::transaction(function()use($b,$d){$lines=[];$total=0;foreach($d['items'] as $row){$variant=Variant::where('business_id',$b->id)->with('product')->findOrFail($row['variant_id']);$qty=round((float)$row['quantity'],3);$price=(float)$variant->price;$amount=round($qty*$price,2);$total+=$amount;$lines[]=[$variant,$qty,$price,$amount];}$q=Quotation::create(['business_id'=>$b->id,'quote_no'=>getGenerateCode(Quotation::where('business_id',$b->id),'quote_no','QT'),'customer_name'=>$d['customer_name'],'customer_phone'=>$d['customer_phone']??null,'valid_until'=>$d['valid_until']??null,'total'=>round($total,2),'status'=>'open']);foreach($lines as [$variant,$qty,$price,$amount])QuotationItem::create(['business_id'=>$b->id,'quotation_id'=>$q->id,'variant_id'=>$variant->id,'quantity'=>$qty,'price'=>$price,'total'=>$amount]);});return redirect()->route('business.admin.retail.quotations.index')->with('success',t('Quotation created.','কোটেশন তৈরি হয়েছে।'));}
 public function convert(Request $r,int $record,Access $a,Sales $sales){$v=$a->check($r,'sales','quotations','quotation-list','update');$b=$v['business'];DB::transaction(function()use($b,$record,$sales){$q=Quotation::where('business_id',$b->id)->lockForUpdate()->findOrFail($record);if($q->status!=='open'||($q->valid_until && now()->startOfDay()->gt($q->valid_until)))throw ValidationException::withMessages(['quotation'=>'Quotation expired or already converted.']);$items=QuotationItem::where('business_id',$b->id)->where('quotation_id',$q->id)->get();$o=$sales->create($b,['request_key'=>'quotation:'.$q->id,'customer_name'=>$q->customer_name,'customer_phone'=>$q->customer_phone,'items'=>$items->map(fn($i)=>['variant_id'=>$i->variant_id,'quantity'=>$i->quantity])->all()],'admin');$q->update(['order_id'=>$o->id,'status'=>'converted']);});return back()->with('success',t('Converted to a sales order using current prices.','বর্তমান দামে সেলস অর্ডার তৈরি হয়েছে।'));}
}
