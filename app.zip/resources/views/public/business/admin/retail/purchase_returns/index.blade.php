@extends('public.business.admin.layout')
@section('content')
<div class="ret-page listui-page">@include('public.business.admin.retail._styles')
@include('public.business.admin.shared.list-ui.styles')
@include('public.business.admin.sidebar')<div class="ws-sidebar-overlay" data-ws-sidebar-overlay></div>
<main class="workspace-content"><div class="ret-title cfg-heading"><div><button type="button" class="ret-btn alt ret-mobile-nav" data-ws-sidebar-toggle>☰</button><div class="cfg-eyebrow">{{ t('Purchase','ক্রয়') }} / {{ t('Purchase Returns','ক্রয় ফেরত') }}</div><h1>{{ t("Purchase Returns","ক্রয় রিটার্ন") }}</h1><p>{{ t('Business workspace','বিজনেস ওয়ার্কস্পেস') }}</p></div></div>
@if(session('success'))<div class="ret-toast">{{ session('success') }}</div>@endif
@if($errors->any())<div class="ret-error">{{ $errors->first() }}</div>@endif
<div class="listui-add"><button type="button" class="ret-btn" data-listui-open="listui-create">+ {{ t('New Purchase Return','নতুন ক্রয় ফেরত') }}</button></div>
<div class="listui-overlay" id="listui-create" data-listui-modal @if($errors->any()) data-listui-reopen="1" @endif hidden>
 <div class="listui-dialog" role="dialog" aria-modal="true" aria-labelledby="listui-create-title" tabindex="-1">
  <div class="listui-dialog-head"><h2 id="listui-create-title">{{ t('New Purchase Return','নতুন ক্রয় ফেরত') }}</h2><button type="button" class="listui-dialog-close" data-listui-close aria-label="{{ t('Close','বন্ধ') }}">×</button></div>
  <div class="listui-dialog-body"><form class="ret-card" method="POST" action="{{ route('business.admin.purchase.purchase-returns.purchase-return-list.store') }}">@csrf<div class="ret-grid"><div class="ret-field"><label>{{ t('GRN Item','ক্রয় পণ্যের লাইন') }}</label><select class="ret-input" name="purchase_item_id" required><option value="">—</option>@foreach($purchases as $purchase)@foreach($purchase->items as $item)<option value="{{ $item->id }}">{{ $purchase->purchase_no }} / {{ $item->variant?->sku }} ({{ $item->quantity }} @ {{ $item->cost }})</option>@endforeach @endforeach</select></div><div class="ret-field"><label>{{ t('Quantity','পরিমাণ') }}</label><input class="ret-input" type="number" name="quantity" step=".001" min=".001" required></div><div class="ret-field"><label>{{ t('Refund Method','টাকা ফেরতের মাধ্যম') }}</label><select class="ret-input" name="refund_method"><option value="cash">Cash</option><option value="bank">Bank</option></select></div><div class="ret-field"><label>{{ t('Reason','কারণ') }}</label><input class="ret-input" name="reason"></div></div><button class="ret-btn" style="margin-top:12px">{{ t('Return & Post Accounts','রিটার্ন ও হিসাব পোস্ট') }}</button></form></div>
 </div>
</div>@php $columns=['purchase_id'=>'Reference','variant_id'=>'Variant ID','quantity'=>'Quantity','amount'=>'Amount','created_at'=>'Date']; @endphp @include('public.business.admin.retail._table')
</main></div>
@include('public.business.admin.shared.list-ui.scripts')
@endsection
