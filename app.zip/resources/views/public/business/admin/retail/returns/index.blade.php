@extends('public.business.admin.layout')
@section('content')
<div class="ret-page listui-page">
@include('public.business.admin.retail._styles')
@include('public.business.admin.shared.list-ui.styles')
@include('public.business.admin.sidebar')
<div class="ws-sidebar-overlay" data-ws-sidebar-overlay></div><main class="workspace-content">
<div class="ret-title cfg-heading"><div><button type="button" class="ret-btn alt ret-mobile-nav" data-ws-sidebar-toggle>☰</button><div class="cfg-eyebrow">{{ t('Sales','বিক্রয়') }} / {{ t('Sales Returns','বিক্রয় ফেরত') }}</div><h1>{{ t('Sales Returns','বিক্রয় রিটার্ন') }}</h1><p>{{ t('Business workspace','বিজনেস ওয়ার্কস্পেস') }}</p></div></div>
@if(session('success'))<div class="ret-toast">{{ session('success') }}</div>@endif
@if($errors->any())<div class="ret-error">{{ $errors->first() }}</div>@endif
@php $columns=['order_id'=>'Order ID','amount'=>'Credit Amount','refunded'=>'Refunded','reason'=>'Reason','created_at'=>'Date']; @endphp
<div class="ret-toolbar"><a class="ret-btn" href="{{ route('business.admin.sales.returns.new-return.create') }}">+ {{ t('Open / New','খুলুন / নতুন') }}</a></div>
<div class="listui-add"><button type="button" class="ret-btn" data-listui-open="listui-create">+ {{ t('Post Refund','রিফান্ড পোস্ট') }}</button></div>
<div class="listui-overlay" id="listui-create" data-listui-modal @if($errors->any()) data-listui-reopen="1" @endif hidden>
 <div class="listui-dialog" role="dialog" aria-modal="true" aria-labelledby="listui-create-title" tabindex="-1">
  <div class="listui-dialog-head"><h2 id="listui-create-title">{{ t('Post Refund','রিফান্ড পোস্ট') }}</h2><button type="button" class="listui-dialog-close" data-listui-close aria-label="{{ t('Close','বন্ধ') }}">×</button></div>
  <div class="listui-dialog-body"><form method="POST" action="{{ route('business.admin.sales.returns.return-list.refund') }}">@csrf<div class="ret-grid"><div class="ret-field"><label>{{ t('Return ID','রিটার্ন আইডি') }}</label><input class="ret-input" name="return_id" type="number" required min="1"></div><div class="ret-field"><label>{{ t('Amount','পরিমাণ') }}</label><input class="ret-input" name="amount" type="number" required min=".01" step=".01"></div><div class="ret-field"><label>{{ t('Payment Method','পেমেন্ট পদ্ধতি') }}</label><select class="ret-input" name="method"><option value="cash">Cash</option><option value="bank">Bank</option></select></div><div class="ret-field"><label>{{ t('Reference','রেফারেন্স') }}</label><input class="ret-input" name="reference_no"></div></div><button class="ret-btn" style="margin-top:14px">{{ t('Post Refund','রিফান্ড পোস্ট') }}</button></form></div>
 </div>
</div>@include('public.business.admin.retail._table')
</main></div>
@include('public.business.admin.shared.list-ui.scripts')
@endsection
