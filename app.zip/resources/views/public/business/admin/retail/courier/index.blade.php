@extends('public.business.admin.layout')
@section('content')
<div class="ret-page listui-page">@include('public.business.admin.retail._styles')
@include('public.business.admin.shared.list-ui.styles')
@include('public.business.admin.sidebar')<div class="ws-sidebar-overlay" data-ws-sidebar-overlay></div>
<main class="workspace-content"><div class="ret-title cfg-heading"><div><button type="button" class="ret-btn alt ret-mobile-nav" data-ws-sidebar-toggle>☰</button><div class="cfg-eyebrow">{{ t('Delivery & Logistics','ডেলিভারি ও লজিস্টিকস') }} / {{ t('Courier','কুরিয়ার') }}</div><h1>{{ t("Pathao Courier Bookings","পাঠাও কুরিয়ার বুকিং") }}</h1><p>{{ t('Business workspace','বিজনেস ওয়ার্কস্পেস') }}</p></div></div>
@if(session('success'))<div class="ret-toast">{{ session('success') }}</div>@endif
@if($errors->any())<div class="ret-error">{{ $errors->first() }}</div>@endif
<div class="listui-add"><button type="button" class="ret-btn" data-listui-open="listui-create">+ {{ t('Book Courier','কুরিয়ার বুকিং') }}</button></div>
<div class="listui-overlay" id="listui-create" data-listui-modal @if($errors->any()) data-listui-reopen="1" @endif hidden>
 <div class="listui-dialog" role="dialog" aria-modal="true" aria-labelledby="listui-create-title" tabindex="-1">
  <div class="listui-dialog-head"><h2 id="listui-create-title">{{ t('Book Courier','কুরিয়ার বুকিং') }}</h2><button type="button" class="listui-dialog-close" data-listui-close aria-label="{{ t('Close','বন্ধ') }}">×</button></div>
  <div class="listui-dialog-body"><form class="ret-card" method="POST" action="{{ route(request()->routeIs('business.admin.logistics.*')?'business.admin.logistics.courier.courier-booking.book':'business.admin.ecommerce.online-orders.fulfillment.courier.book') }}">@csrf<div class="ret-grid"><div class="ret-field"><label>{{ t('Online Order','অনলাইন অর্ডার') }}</label><select name="order_id" class="ret-input" required>@foreach($orders as $o)<option value="{{ $o->id }}">{{ $o->order_no }} · {{ $o->customer_name }} · {{ $o->customer_phone }}</option>@endforeach</select></div><div class="ret-field"><label>City ID</label><input type="number" name="recipient_city" class="ret-input" min="1" required></div><div class="ret-field"><label>Zone ID</label><input type="number" name="recipient_zone" class="ret-input" min="1" required></div><div class="ret-field"><label>Area ID (optional)</label><input type="number" name="recipient_area" class="ret-input" min="1"></div><div class="ret-field"><label>Parcel weight (kg)</label><input type="number" step=".1" min=".1" name="item_weight" class="ret-input" value=".5" required></div></div><button class="ret-btn" style="margin-top:12px">{{ t('Book Courier','কুরিয়ার বুকিং') }}</button><p class="ret-help">{{ t('Use city/zone IDs from your Pathao merchant account. Do not retry an unknown result without checking Pathao.','পাঠাও অ্যাকাউন্টের City/Zone ID ব্যবহার করুন। Unknown status হলে যাচাই ছাড়া পুনরায় বুক করবেন না।') }}</p></form></div>
 </div>
</div>@php $columns=['order_id'=>'Order','consignment_id'=>'Tracking','status'=>'Status','created_at'=>'Created'];$rowActions='public.business.admin.retail._rows.courier'; @endphp @include('public.business.admin.retail._table')
</main></div>
@include('public.business.admin.shared.list-ui.scripts')
@endsection
