<a class="ret-btn alt" href="{{ route('store.admin.retail.orders.show',['order'=>$record->id]) }}">{{ t('View / Edit','দেখুন / সম্পাদনা') }}</a>
