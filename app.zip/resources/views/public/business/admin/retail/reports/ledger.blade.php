@extends('public.business.admin.layout')
@section('content')
<div class="ret-page listui-page">@include('public.business.admin.retail._styles')
@include('public.business.admin.sidebar')<div class="ws-sidebar-overlay" data-ws-sidebar-overlay></div><main class="workspace-content">
<div class="ret-title cfg-heading"><div><button type="button" class="ret-btn alt ret-mobile-nav" data-ws-sidebar-toggle>☰</button><div class="cfg-eyebrow">{{ t('Sales','বিক্রয়') }} / {{ t('Reports','রিপোর্ট') }}</div><h1>{{ t('General Ledger','জেনারেল লেজার') }}</h1></div></div>
@php $columns=['journal_id'=>'Journal','account_id'=>'Account ID','debit'=>'Debit','credit'=>'Credit','created_at'=>'Date']; @endphp @include('public.business.admin.retail._table')
</main></div>@endsection